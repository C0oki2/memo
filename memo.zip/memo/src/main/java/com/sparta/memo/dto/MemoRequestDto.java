package com.sparta.memo.dto;

import lombok.Getter;

@Getter
public class MemoRequestDto {
    private String title;
    private String writer;
    private String password;
    private String contents;



@Getter
public static class PasswordDto{
    private String password;
}


}

