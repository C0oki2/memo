package com.sparta.notice.service;

import com.sparta.memo.dto.MemoRequestDto;
import com.sparta.memo.dto.MemoResponseDto;
import com.sparta.memo.entity.Memo;
import com.sparta.memo.repository.MemoRepository;
import com.sparta.notice.dto.NoticeRequestDto;
import com.sparta.notice.dto.NoticeResponseDto;
import com.sparta.notice.entity.Notice;
import com.sparta.notice.repository.NoticeRepository;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class MemoService {
    private final MemoRepository memoRepository;

    public MemoResponseDto createMemo(MemoRequestDto requestDto) {
        // RequestDto -> Entity
        Memo memo = new Memo(requestDto);

        Memo saveMemo = memoRepository.save(memo);

        // Entity -> ResponseDto
        MemoResponseDto memoResponseDto = new MemoResponseDto(saveMemo);
        return memoResponseDto;
    }


    public List<MemoResponseDto> getMemo() {
        return memoRepository.findAllByOrderByCreatedAtDesc().stream().map(MemoResponseDto::new).toList();
    }



    public List<MemoResponseDto> getIdMemo(Long id) {
        return memoRepository.findAllByOrderByCreatedAtDesc().stream().filter(n -> n.getId() == id).map(MemoResponseDto::new).toList();
    }

    @Transactional
    public Memo updateMemo(Long id, MemoRequestDto requestDto) {
        // 해당 게시글이 DB에 존재하는지 확인
        Memo memo = findMemo(id);

        if(memo.getPassword().equals(requestDto.getPassword())){
            memo.update(requestDto);
        }
        return  memo;
    }

    public Long deleteMemo(Long id, MemoRequestDto.PasswordDto requestDto) {
        // 해당 게시글이 DB에 존재하는지 확인
        Memo memo = findMemo(id);
        if(comparePassWord(id, requestDto)){
            memoRepository.delete(memo);
            return  id;
        }

        return  -1L;
    }

    private Memo findMemo(Long id) {
        return memoRepository.findById(id).orElseThrow(() ->
                new IllegalArgumentException("선택한 메모는 존재하지 않습니다.")
        );
    }

    private boolean comparePassWord(Long id, MemoRequestDto.PasswordDto requestDto){
        Memo memo = memoRepository.findById(id).orElseThrow(() ->
                new IllegalArgumentException("선택한 메모는 존재하지 않습니다."));
        return Objects.equals(memo.getPassword(), requestDto.getPassword());
    }
}
