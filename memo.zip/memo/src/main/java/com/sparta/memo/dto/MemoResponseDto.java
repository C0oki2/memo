package com.sparta.memo.dto;

import com.sparta.memo.entity.Memo;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
public class MemoResponseDto {
    private Long id;
    private String title;
    private String writer;
    private String password;
    private String contents;
    private LocalDateTime createdAt;


    public MemoResponseDto(Memo memo){
        this.id = memo.getId();
        this.title = memo.getTitle();
        this.writer = memo.getWriter();
        this.password = memo.getPassword();
        this.contents = memo.getContents();
        this.createdAt = memo.getCreatedAt();
    }

    public MemoResponseDto(Long id, String title, String writer, String password, String contents) {
        this.id = id;
        this.title = title;
        this.writer = writer;
        this.password = password;
        this.contents = contents;
    }
}